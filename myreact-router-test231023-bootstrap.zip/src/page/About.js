import React from 'react';

export default function About(){
    return (<div className='container mt-5'>
      <h3>About Page</h3>
    </div>);
}