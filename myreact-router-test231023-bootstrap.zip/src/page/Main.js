import React from "react";

export default function Main() {
  return (
    <div className="container mt-5">
      <h3>Main Page</h3>
    </div>
  );
}